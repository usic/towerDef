function open_pop_up(box) {
	$("#overlay").show();
	$(box).center_pop_up();
	$(box).show(2);
}
 
function close_pop_up(box) {
	$(box).hide(2);
	$("#overlay").delay(1).hide(1);
	$("#overlay_pause").delay(1).hide(1);
}

function log_in() {
	$(".user").css('display','block');
	$(".logged").css('display','block');
	$("#play").css('display','inline-block');
	$("#enter").css('display','none');
	$('input').attr('value','');
}

function log_out() {
	$(".user").css('display','none');
	$(".logged").css('display','none');
	$("#play").css('display','none');
	$("#enter").css('display','inline-block');
}

function play() {
	$(".content").css('display','none');
	$("body").css('background-image','none');
	$(".game").css('display','block');
}

function pause() {
	$("#overlay_pause").show();
	$("#on_pause").center_pop_up();
	$("#on_pause").show(2);
}

function game_over() {
	close_pop_up("#on_pause");
	$("#game_over").center_pop_up();
	$("#game_over").show(2);
}

function exit() {
	close_pop_up("#on_pause");
	$(".game").css('display','none');
	$(".content").css('display','block');
	$("body").css('background-image','url(../assets/Background.png)');
}

$(document).ready(function(){
 
	jQuery.fn.center_pop_up = function(){
		this.css('position','absolute');  
		this.css('top', ($(window).height() - this.height()) / 2 + 'px');  
		this.css('left', ($(window).width() - this.width()) / 2 + 'px');
	}
 
});